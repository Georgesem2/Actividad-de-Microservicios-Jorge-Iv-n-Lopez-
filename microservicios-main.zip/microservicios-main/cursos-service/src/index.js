const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 3002;

app.use(cors());
app.use(express.json());


let cursos = [];
let contadorId = 1;
// ruta principal

app.get('/', (req, res) => {
    res.send('Cursos-service funcionando');
});

// healt check
app.get('/health', (req, res) => {  
    res.json({
        servicio: "cursos-service",
        estado: "OK"
    });
});

// crear curso

app.post('/cursos', (req, res) => {
    const { nombre, creditos } = req.body;

    if (!nombre || !creditos) {
        return res.status(400).json({ error: 'Nombre y créditos son obligatorios' });
    }

    const nuevoCurso = {
        id: cursos.length + 1,
        nombre,
        creditos
    };

    cursos.push(nuevoCurso);

    res.status(201).json(nuevoCurso);
});

// obtener todos los cursos
app.get('/cursos', (req, res) => {
    res.json(cursos);
});

// obtener curso por id
app.get('/cursos/:id', (req, res) => {
    const id = Number(req.params.id);
    const curso = cursos.find(c => c.id === id);

    if (!curso) {
        return res.status(404).json({ error: 'Curso no encontrado' });
    }
    res.json(curso);
}); 

app.listen(PORT, () => {
    console.log(`Cursos-service escuchando en el puerto http://localhost:${PORT}`);
});