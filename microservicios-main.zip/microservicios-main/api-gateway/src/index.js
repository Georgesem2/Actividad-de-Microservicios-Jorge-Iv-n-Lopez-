const express = require('express');
const cors = require('cors');
const axios = require('axios');

const app = express();

const PORT = 3000;

app.use(cors());
app.use(express.json());

// URLs de microservicios
const USUARIOS_SERVICE = 'http://usuarios-service:3001';
const CURSOS_SERVICE = 'http://cursos-service:3002';
const MATRICULAS_SERVICE = 'http://matriculas-service:3003';
const PROFESORES_SERVICE = 'http://profesores-service:3004';

// Ruta principal
app.get('/', (req, res) => {
    res.json({
        mensaje: 'API Gateway funcionando',
        endpoints: {
            usuarios: {
                obtener: 'GET /api/usuarios',
                crear: 'POST /api/usuarios'
            },

            cursos: {
                obtener: 'GET /api/cursos',
                crear: 'POST /api/cursos'
            },  
            matriculas: {
                obtener: 'GET /api/matriculas',
                crear: 'POST /api/matriculas'

            },
            profesores: {
                obtener: 'GET /api/profesores',
                crear: 'POST /api/profesores'
            },
            resumen: {
                matriculas: 'GET /api/resumen/matriculas'
            }
        }
    });
});

// =====================
// USUARIOS
// =====================

// Obtener usuarios
app.get('/api/usuarios', async (req, res) => {

    try {

        const respuesta = await axios.get(
            `${USUARIOS_SERVICE}/usuarios`
        );

        res.json(respuesta.data);

    } catch (error) {

        res.status(500).json({
            error: error.message
        });

    }

});

// Crear usuario
app.post('/api/usuarios', async (req, res) => {

    try {

        const respuesta = await axios.post(
            `${USUARIOS_SERVICE}/usuarios`,
            req.body
        );

        res.status(201).json(respuesta.data);

    } catch (error) {

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================
// CURSOS
// =====================

// Obtener cursos
app.get('/api/cursos', async (req, res) => {

    try {

        const respuesta = await axios.get(
            `${CURSOS_SERVICE}/cursos`
        );

        res.json(respuesta.data);

    } catch (error) {

        res.status(500).json({
            error: error.message
        });

    }

});

// Crear curso
app.post('/api/cursos', async (req, res) => {

    try {

        const respuesta = await axios.post(
            `${CURSOS_SERVICE}/cursos`,
            req.body
        );

        res.status(201).json(respuesta.data);

    } catch (error) {

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================
// MATRICULAS
// =====================

// Obtener matrículas
app.get('/api/matriculas', async (req, res) => {

    try {

        const respuesta = await axios.get(
            `${MATRICULAS_SERVICE}/matriculas`
        );

        res.json(respuesta.data);

    } catch (error) {

        res.status(500).json({
            error: error.message
        });

    }

});

// Crear matrícula
app.post('/api/matriculas', async (req, res) => {

    try {

        const { usuarioId, cursoId } = req.body;

        // Validar usuario
        await axios.get(
            `${USUARIOS_SERVICE}/usuarios/${usuarioId}`
        );

        // Validar curso
        await axios.get(
            `${CURSOS_SERVICE}/cursos/${cursoId}`
        );

        // Crear matrícula
        const respuesta = await axios.post(
            `${MATRICULAS_SERVICE}/matriculas`,
            {
                usuarioId,
                cursoId
            }
        );

        res.status(201).json({
            mensaje: 'Matrícula creada correctamente',
            matricula: respuesta.data
        });

    } catch (error) {

        res.status(500).json({
            error: error.message
        });

    }

});
//====================
// PROFESORES
//====================

//obtenr profesores
app.get('/api/profesores', async (req, res) => {

    try {

        const respuesta = await axios.get(
            `${PROFESORES_SERVICE}/profesores`
        );

        res.json(respuesta.data);

    } catch (error) {

        res.status(500).json({
            error: error.message
        });
    }

});

//crear profesor

app.post('/api/profesores', async (req, res) => {

    try {

        const respuesta = await axios.post(
            `${PROFESORES_SERVICE}/profesores`,
            req.body
        );
        res.status(201).json(respuesta.data);
    } catch (error) {

        res.status(500).json({
            error: error.message
        });
    }
});

// =====================
// RESUMEN
// =====================

app.get('/api/resumen/matriculas', async (req, res) => {

    try {

        const usuariosRes = await axios.get(
            `${USUARIOS_SERVICE}/usuarios`
        );

        const cursosRes = await axios.get(
            `${CURSOS_SERVICE}/cursos`
        );

        const matriculasRes = await axios.get(
            `${MATRICULAS_SERVICE}/matriculas`
        );

        const usuarios = usuariosRes.data;
        const cursos = cursosRes.data;
        const matriculas = matriculasRes.data;

        const resumen = matriculas.map((matricula) => {

            const usuario = usuarios.find(
                (u) => u.id == matricula.usuarioId
            );

            const curso = cursos.find(
                (c) => c.id == matricula.cursoId
            );

            return {
                idMatricula: matricula.id,
                estudiante: usuario
                    ? usuario.nombre
                    : 'Usuario no encontrado',

                curso: curso
                    ? curso.nombre
                    : 'Curso no encontrado',

                fecha: matricula.fecha
            };

        });

        res.json(resumen);

    } catch (error) {

        res.status(500).json({
            error: error.message
        });

    }

});


// Iniciar servidor
app.listen(PORT, () => {
    console.log(`
        Url base:
        http://localhost:${PORT}
        
        endpoints disponibles:
        
        Usuarios:
        GET /api/usuarios
        POST /api/usuarios
        
        Cursos:
        GET /api/cursos
        POST /api/cursos
        
        Matrículas:
        GET /api/matriculas
        POST /api/matriculas
        
        Profesores:
        GET /api/profesores
        POST /api/profesores
        
        resumen:
        GET /api/resumen/matriculas

        =====================
        listo
        =====================
        
        `
    );
});