const express = require('express');
const cors = require('cors');

const app = express();


const PORT = 3004;

app.use(cors());
app.use(express.json());

let profesores = [];
let contadorId = 1;

//ruta principal
app.get('/', (req, res) => {
    res.send('profesores-service funcionando');
});

// health check
app.get('/health', (req, res) => {
    res.json({ servicio: 'profesores-service', status: 'ok' });
});

// crear profesor
app.post('/profesores', (req, res) => {

    const { nombre, especialidad} = req.body;

    if (!nombre || !especialidad) {
        return res.status(400).json({ error: 'nombre y especialidad son campos obligatorios' });
    }

    const nuevoProfesor = {
        id: contadorId++,
        nombre,
        especialidad
    };
    profesores.push(nuevoProfesor);
    res.status(201).json(nuevoProfesor);

});

// obtener profesores
app.get('/profesores', (req, res) => {
    res.json(profesores);
});

// obtener profesor por id
app.get('/profesores/:id', (req, res) => {
    const id = Number(req.params.id);

    const profesor = profesores.find(p => p.id === id);

    if (!profesor) {
        return res.status(404).json({ error: 'Profesor no encontrado' });
    }   
    res.json(profesor);
});

//iniciar servidor
app.listen(PORT, () => {
    console.log(`profesores-service escuchando en el puerto http://localhost:${PORT}`);
});
