const express = require('express');
const cors = require('cors');
const app = express();

const PORT = 3001;

app.use(cors());
app.use(express.json());

let usuarios = [];
let contadorId = 1;

// ruta principal 
app.get('/', (req, res) => {
    res.send('Usuarios-service funcionando');
});

// healt check
app.get('/health', (req, res) => {
    res.json({
        servicio: "usuarios-service",
        estado: "OK"
    });
});

// crea usuario
app.post('/usuarios', (req, res) => {

    const { nombre, email } = req.body;

    if (!nombre || !email) {
        return res.status(400).json({ error: 'Nombre y email son obligatorios' });
    }

    const nuevoUsuario = {
        id: contadorId++,
        nombre,
        email
    };  

    usuarios.push(nuevoUsuario);
    res.status(201).json(nuevoUsuario);
});

// obtener todos los usuarios
app.get('/usuarios', (req, res) => {
    res.json(usuarios);
});

// obtener usuario por id
app.get('/usuarios/:id', (req, res) => {
    const id =  Number(req.params.id);

    const usuario = usuarios.find(u => u.id === id);

    if (!usuario) {
        return res.status(404).json({ error: 'Usuario no encontrado' });
    }
    res.json(usuario);
});

//encender servidor 
app.listen(PORT, () => {
    console.log(`Usuarios-service ejecutandoce en http://localhost:${PORT}`);
});